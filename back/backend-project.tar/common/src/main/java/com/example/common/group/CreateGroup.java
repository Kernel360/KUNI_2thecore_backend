package com.example.common.group;

public interface CreateGroup { // 유효성 검사 그룹
}
