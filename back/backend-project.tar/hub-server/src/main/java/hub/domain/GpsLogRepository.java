package hub.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GpsLogRepository extends JpaRepository<GpsLogEntity, Integer> {
}
