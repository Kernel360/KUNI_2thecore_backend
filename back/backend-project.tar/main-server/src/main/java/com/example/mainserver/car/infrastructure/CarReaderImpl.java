package com.example.mainserver.car.infrastructure;

public class CarReaderImpl {
}
